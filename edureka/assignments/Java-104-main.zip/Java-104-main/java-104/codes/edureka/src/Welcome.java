
public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to Java Training");
		System.out.print("by ");
		System.out.println("team @ edureka");
	}

}
