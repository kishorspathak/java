
public class BooleanType {

	public static void main(String[] args) {
		boolean result;
		//int x = 45;
		int x = 25;
		int y = 34;
		
		result = x > y;
		System.out.println(result);
	}

}
