public class String1 {
	public static void main (String args[])
	{
		String str1 = "Hello";
		String str2 = " World";
		String str3 = str1 + str2;
		System.out.println ("Concatenated string is : "+str3);
	}

}