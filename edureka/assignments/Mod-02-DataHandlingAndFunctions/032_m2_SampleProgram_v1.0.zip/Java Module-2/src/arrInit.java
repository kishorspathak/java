class arrInit
{
  public static void main (String args[])
  { 
    int i;
    int[] a = {10, 20, 30, 40, 50};
for (i = 0; i < 5; ++i)
  System.out.println (a[i]);
  }
}
